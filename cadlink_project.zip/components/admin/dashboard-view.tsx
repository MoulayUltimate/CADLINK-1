export { Dashboard as DashboardView } from './dashboard'
